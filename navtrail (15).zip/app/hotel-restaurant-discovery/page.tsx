import { HotelRestaurantDiscovery } from "@/components/hotel-restaurant-discovery"

export default function HotelRestaurantDiscoveryPage() {
  return <HotelRestaurantDiscovery />
}

