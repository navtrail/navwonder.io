import { NavigationScreen } from "@/components/navigation-screen"

export default function NavigationPage() {
  return <NavigationScreen />
}

