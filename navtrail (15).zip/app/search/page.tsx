import { SearchScreen } from "@/components/search-screen"

export default function SearchPage() {
  return <SearchScreen />
}

