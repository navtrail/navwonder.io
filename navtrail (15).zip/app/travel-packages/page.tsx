import { TravelPackages } from "@/components/travel-packages"

export default function TravelPackagesPage() {
  return <TravelPackages />
}

