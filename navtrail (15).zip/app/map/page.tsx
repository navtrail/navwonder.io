import { MapScreen } from "@/components/map-screen"

export default function MapPage() {
  return <MapScreen />
}

