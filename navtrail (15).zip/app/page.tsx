import { HomeScreen } from "@/components/home-screen"

export default function Home() {
  return <HomeScreen />
}

