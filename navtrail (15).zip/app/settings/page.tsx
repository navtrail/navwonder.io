import { SettingsScreen } from "@/components/settings-screen"

export default function SettingsPage() {
  return <SettingsScreen />
}

