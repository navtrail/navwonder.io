import { TripPlanningScreen } from "@/components/trip-planning-screen"

export default function TripPlanningPage() {
  return <TripPlanningScreen />
}

