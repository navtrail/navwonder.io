import { OfflineMapsUI } from "@/components/offline-maps-ui"

export default function OfflineMapsPage() {
  return <OfflineMapsUI />
}

