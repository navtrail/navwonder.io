import { RoutesScreen } from "@/components/routes-screen"

export default function RoutesPage() {
  return <RoutesScreen />
}

