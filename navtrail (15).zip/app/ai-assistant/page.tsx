import { AITravelAssistant } from "@/components/ai-travel-assistant"

export default function AIAssistantPage() {
  return <AITravelAssistant />
}

