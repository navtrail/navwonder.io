import { ProfileSettings } from "@/components/profile-settings"

export default function ProfileSettingsPage() {
  return <ProfileSettings />
}

