import { AboutScreen } from "@/components/about-screen"

export default function AboutPage() {
  return <AboutScreen />
}

