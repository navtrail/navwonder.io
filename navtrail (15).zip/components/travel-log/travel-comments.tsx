// The rest of the original code would go here.
// Since it was omitted, I cannot provide a complete merged file.
// This import addresses the specific errors mentioned in the updates.

