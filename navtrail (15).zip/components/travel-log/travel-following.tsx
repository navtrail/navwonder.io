// Unable to provide a merged code block because the existing code was omitted for brevity, and the updates indicate undeclared variables without providing context or code snippets to fix them. Without the original code, it's impossible to determine where and how to declare or import the missing variables. A proper response requires the original code to be provided.

